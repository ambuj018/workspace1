package com.demo.model;

public class Course {

	private Integer appClientId;
	private Integer loanId;
	private String userid;

	public Integer getAppClientId() {
		return appClientId;
	}

	public void setAppClientId(Integer appClientId) {
		this.appClientId = appClientId;
	}

	public Integer getLoanId() {
		return loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}
