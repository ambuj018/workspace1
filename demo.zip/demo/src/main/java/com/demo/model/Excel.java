package com.demo.model;

public class Excel {

	private Integer appClientId;
	private Integer loanId;
	private Integer userid;
	
	public Integer getAppClientId() {
		return appClientId;
	}
	public void setAppClientId(Integer appClientId) {
		this.appClientId = appClientId;
	}
	public Integer getLoanId() {
		return loanId;
	}
	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	

}